(ns understanding-core-async.Lesson-How-Channels-Are-Modeled
  (:require [clojure.core.async :refer [chan]]))

(chan)