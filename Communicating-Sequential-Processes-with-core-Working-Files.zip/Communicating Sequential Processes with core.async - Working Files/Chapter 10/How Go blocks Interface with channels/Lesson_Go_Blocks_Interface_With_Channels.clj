(ns understanding-core-async.Lesson-Go-Blocks-Interface-With-Channels
  (:require [clojure.core.async :refer [go]]))

(go)

